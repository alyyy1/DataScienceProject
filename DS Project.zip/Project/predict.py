import numpy as np
from scipy import stats
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.metrics import r2_score
from sklearn.decomposition import PCA
from sklearn.impute import SimpleImputer
from sklearn.tree import DecisionTreeRegressor
from sklearn.preprocessing import MinMaxScaler
from sklearn.neighbors import KNeighborsRegressor
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.feature_selection import SelectKBest, chi2

cars_df = pd.read_csv("C:\\Users\\DC\\Downloads\\CARS_1.csv")
# print(cars_df)

imputer = SimpleImputer(missing_values=np.nan, strategy='mean')
imputer.fit(cars_df[['seating_capacity']])
cars_df['seating_capacity'] = imputer.transform(cars_df[['seating_capacity']])
# print(cars_df.isnull().sum())

zscores = cars_df.select_dtypes(include='number').apply(stats.zscore)
# print(zscores)
outlier_rows = (zscores > 3).any(axis=1)
# print(outlier_rows.sum())
cars_df = cars_df.drop(cars_df[outlier_rows].index)
# print(cars_df)

X=cars_df.drop(['starting_price','ending_price','car_name'],axis=1)
y=cars_df['starting_price']

categorical_features = ['fuel_type', 'transmission_type', 'body_type']
X_encoded = pd.get_dummies(X, columns=categorical_features)
# print(X_encoded.columns)


Bestfeatures = SelectKBest(score_func=chi2, k=6)
fit = Bestfeatures.fit(X_encoded, y)

dfscores = pd.DataFrame(fit.scores_)
dfcolumns = pd.DataFrame(X_encoded.columns)

featurescores = pd.concat([dfcolumns, dfscores], axis=1)
featurescores.columns = ['Specs', 'Scores']
# print(featurescores.nlargest(6, 'Scores'))
Bestcol = featurescores.nlargest(6, 'Scores')
Bestcol = Bestcol.Specs
Bestcol = X_encoded[Bestcol]
# print(Bestcol)

# pca=PCA()
# X_pca = pca.fit_transform(X_encoded)

# X_train, X_test, y_train, y_test = train_test_split(X_pca, y, test_size=0.2, random_state=42)

X_train, X_test, y_train, y_test = train_test_split(Bestcol, y, test_size=0.2, random_state=42)

scaler = MinMaxScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)
# print(X_scaled)

lr_model = LinearRegression()
lr_model.fit(X_train_scaled,y_train)
y_pred_lr = lr_model.predict(X_test_scaled)

knn_model = KNeighborsRegressor(n_neighbors=9)  
knn_model.fit(X_train_scaled, y_train)
y_pred_knn = knn_model.predict(X_test_scaled)

model_rfr = RandomForestRegressor(random_state=42)
model_rfr.fit(X_train_scaled,y_train)
y_pred_rfr = model_rfr.predict(X_test_scaled)

model_dtr = DecisionTreeRegressor(random_state=42)
model_dtr.fit(X_train_scaled,y_train)
y_pred_dtr = model_dtr.predict(X_test_scaled)

model_gbr = GradientBoostingRegressor()
model_gbr.fit(X_train_scaled,y_train)
y_pred_gbr = model_gbr.predict(X_test_scaled)

r2_lr = r2_score(y_test, y_pred_lr)
variance_explained_lr = r2_lr * 100
print("Percentage of variance explained of Linear Regression:", variance_explained_lr)

r2_knn = r2_score(y_test, y_pred_knn)
variance_explained_knn = r2_knn * 100
print("Percentage of variance explained of KNN:", variance_explained_knn)

r2_rfr = r2_score(y_test, y_pred_rfr)
variance_explained_rfr = r2_rfr * 100
print("Percentage of variance explained of Random Forest Regressor:", variance_explained_rfr)

r2_dtr = r2_score(y_test, y_pred_dtr)
variance_explained_dtr = r2_dtr * 100
print("Percentage of variance explained of Decision Tree Regressor:", variance_explained_dtr)

r2_gbr = r2_score(y_test, y_pred_gbr)
variance_explained_gbr = r2_gbr * 100
print("Percentage of variance explained of Gradient Boosting Regressor:", variance_explained_gbr)

r2_scores = [variance_explained_lr, variance_explained_knn, variance_explained_rfr, variance_explained_dtr, variance_explained_gbr]
algorithms = ['Linear Regression', 'KNN', 'Random Forest', 'Decision Tree', 'Gradient Boosting']

plt.figure(figsize=(8, 6))
plt.bar(algorithms, r2_scores)
plt.xlabel('Algorithms')
plt.ylabel('R2 Score (%)')
plt.title('Comparison of R2 Scores for Different Algorithms')

# Annotate the highest R2 score
best_algorithm_index = np.argmax(r2_scores)
best_algorithm_score = r2_scores[best_algorithm_index]
plt.annotate(f'Best: {best_algorithm_score:.2f}%', xy=(best_algorithm_index, best_algorithm_score),
             xytext=(best_algorithm_index, best_algorithm_score + 5),
             arrowprops=dict(arrowstyle='->'))

plt.show()



