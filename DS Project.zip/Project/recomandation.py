import numpy as np
import pandas as pd
from sklearn.impute import SimpleImputer
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.feature_extraction.text import CountVectorizer
import tkinter as tk

# Load the dataset
cars_df = pd.read_csv("C:\\Users\\DC\\Downloads\\CARS_1.csv")

# Perform data preprocessing
imputer = SimpleImputer(strategy='mean')
cars_df['seating_capacity'] = imputer.fit_transform(cars_df[['seating_capacity']])

features = ['reviews_count', 'engine_displacement', 'no_cylinder', 'seating_capacity',
            'fuel_tank_capacity', 'rating', 'starting_price', 'ending_price',
            'max_torque_nm', 'max_torque_rpm', 'max_power_bhp', 'max_power_rp']

def combined_features(row):
    return ' '.join([str(row[feature]) for feature in features])

cars_df["combined_features"] = cars_df.apply(combined_features, axis=1)

cv = CountVectorizer()
count_matrix = cv.fit_transform(cars_df['combined_features'])

cosine_sim = cosine_similarity(count_matrix)

def get_index_from_title(car_name):
    return cars_df[cars_df['car_name'] == car_name].index[0]

def get_recommendations(car_name):
    car_index = get_index_from_title(car_name)
    similar_cars = list(enumerate(cosine_sim[car_index]))
    sorted_similar_cars = sorted(similar_cars, key=lambda x: x[1], reverse=True)
    recommended_cars = [cars_df.iloc[car[0]]['car_name'] for car in sorted_similar_cars[1:11]]
    return recommended_cars

def show_recommendations():
    input_car_name = entry.get()
    recommended_cars = get_recommendations(input_car_name)
    recommended_cars_str = "\n".join(recommended_cars)
    recommended_cars_text.delete(1.0, tk.END)
    recommended_cars_text.insert(tk.END, recommended_cars_str)

# Create the GUI window
window = tk.Tk()
window.title("Car Recommendation System")

# Create and position the GUI elements
label = tk.Label(window, text="Enter a Car Name:")
label.pack(pady=10)

entry = tk.Entry(window, width=40)
entry.pack()

button = tk.Button(window, text="Get Recommendations", command=show_recommendations)
button.pack(pady=10)

recommended_cars_text = tk.Text(window, height=10, width=50)
recommended_cars_text.pack()

# Start the GUI event loop
window.mainloop()
