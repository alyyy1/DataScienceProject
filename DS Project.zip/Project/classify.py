import numpy as np
from scipy import stats
import pandas as pd
from matplotlib import pyplot as plt
from sklearn.impute import SimpleImputer
from sklearn.decomposition import PCA
from sklearn.metrics import accuracy_score
from sklearn.naive_bayes import GaussianNB
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split


cars_df = pd.read_csv("C:\\Users\\DC\\Downloads\\CARS_1.csv")
# print(cars_df)

imputer = SimpleImputer(missing_values=np.nan, strategy='mean')
imputer.fit(cars_df[['seating_capacity']])
cars_df['seating_capacity'] = imputer.transform(cars_df[['seating_capacity']])
# print(cars_df.isnull().sum())

zscores = cars_df.select_dtypes(include='number').apply(stats.zscore)
# print(zscores)
outlier_rows = (zscores > 3).any(axis=1)
# print(outlier_rows.sum())
cars_df = cars_df.drop(cars_df[outlier_rows].index)
# print(cars_df)

categorical_features = ['fuel_type', 'body_type']
X_encoded = pd.get_dummies(cars_df, columns=categorical_features)
# print(X_encoded.columns)

X=X_encoded.drop(['transmission_type','car_name'],axis=1)
y=X_encoded.transmission_type

scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

pca = PCA(0.95)  
X_pca = pca.fit_transform(X_scaled)

X_train, X_test, y_train, y_test = train_test_split(X_pca, y, test_size=0.2, random_state=42)

model_lr =LogisticRegression()
model_lr.fit(X_train,y_train)
y_pred_lr = model_lr.predict(X_test)

model_knn=KNeighborsClassifier(n_neighbors=11)
model_knn.fit(X_train,y_train)
y_pred_knn = model_knn.predict(X_test)

model_gnb= GaussianNB()
model_gnb.fit(X_train,y_train)
y_pred_gnb = model_gnb.predict(X_test)

accuracy_lr = accuracy_score(y_test, y_pred_lr)*100
print("Accuracy of Logistic Regression model:", accuracy_lr)

accuracy_knn = accuracy_score(y_test, y_pred_knn)*100
print("Accuracy of KNN model:", accuracy_knn)

accuracy_gnb = accuracy_score(y_test, y_pred_gnb)*100
print("Accuracy of Gaussian Naive Bayes model:", accuracy_gnb)

accuracy_scores = [accuracy_lr, accuracy_knn, accuracy_gnb]
algorithms = ['Logistic Regression', 'KNN', 'Gaussian Naive Bayes']

plt.figure(figsize=(8, 6))
plt.bar(algorithms, accuracy_scores)
plt.xlabel('Algorithms')
plt.ylabel('Accuracy Score (%)')
plt.title('Comparison of R2 Scores for Different Algorithms')

# Annotate the highest R2 score
best_algorithm_index = np.argmax(accuracy_scores)
best_algorithm_score = accuracy_scores[best_algorithm_index]
plt.annotate(f'Best: {best_algorithm_score:.2f}%', xy=(best_algorithm_index, best_algorithm_score),
             xytext=(best_algorithm_index, best_algorithm_score + 5),
             arrowprops=dict(arrowstyle='->'))

plt.show()



