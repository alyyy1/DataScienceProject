import pandas as pd
from matplotlib import pyplot as plt
import seaborn as sns

cars_df = pd.read_csv("C:\\Users\\DC\\Downloads\\CARS_1.csv")

# Plot a bar chart showing the count of each body type
plt.figure(figsize=(8, 6))
sns.countplot(data=cars_df, x='body_type')
plt.xlabel('Body Type')
plt.ylabel('Count')
plt.title('Count of Cars by Body Type')
plt.xticks(rotation=45)
plt.show()

# Plot a scatter plot of engine displacement vs. max power
plt.figure(figsize=(8, 6))
sns.scatterplot(data=cars_df, x='engine_displacement', y='max_power_bhp', hue='fuel_type')
plt.xlabel('Engine Displacement')
plt.ylabel('Max Power (bhp)')
plt.title('Engine Displacement vs. Max Power')
plt.legend(title='Fuel Type')
plt.show()

# Plot a histogram of starting prices
plt.figure(figsize=(8, 6))
sns.histplot(data=cars_df, x='starting_price', bins=10)
plt.xlabel('Starting Price')
plt.ylabel('Count')
plt.title('Distribution of Starting Prices')
plt.show()

# Plot a boxplot of rating by body type
plt.figure(figsize=(10, 6))
sns.boxplot(data=cars_df, x='body_type', y='rating')
plt.xlabel('Body Type')
plt.ylabel('Rating')
plt.title('Rating Distribution by Body Type')
plt.xticks(rotation=45)
plt.show()

# Plot a violin plot of fuel type by seating capacity
plt.figure(figsize=(10, 6))
sns.violinplot(data=cars_df, x='fuel_type', y='seating_capacity')
plt.xlabel('Fuel Type')
plt.ylabel('Seating Capacity')
plt.title('Seating Capacity Distribution by Fuel Type')
plt.show()

# Plot a scatter matrix of selected numeric features
numeric_features = ['reviews_count', 'engine_displacement', 'seating_capacity', 'rating', 'starting_price']
sns.set(style='ticks')
sns.pairplot(data=cars_df[numeric_features])
plt.show()
