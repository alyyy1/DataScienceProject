import tkinter as tk
from tkinter import messagebox
import numpy as np
import pandas as pd
from sklearn.impute import SimpleImputer
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.feature_extraction.text import CountVectorizer

cars_df = pd.read_csv("C:\\Users\\DC\\Downloads\\CARS_1.csv")

imputer = SimpleImputer(strategy='mean')
cars_df['seating_capacity'] = imputer.fit_transform(cars_df[['seating_capacity']])

features = ['reviews_count', 'engine_displacement', 'no_cylinder', 'seating_capacity',
            'fuel_tank_capacity', 'rating', 'starting_price', 'ending_price',
            'max_torque_nm', 'max_torque_rpm', 'max_power_bhp', 'max_power_rp']
cars_df['combined_features'] = cars_df[features].astype(str).apply(' '.join, axis=1)

cv = CountVectorizer()
count_matrix = cv.fit_transform(cars_df['combined_features'])

cosine_sim = cosine_similarity(count_matrix)

def get_index_from_title(car_name):
    return cars_df[cars_df['car_name'] == car_name].index[0]

def get_car_recommendations(budget, top_n=10):
    car_index = cars_df[cars_df['starting_price'] <= budget].index
    similar_cars = np.sum(cosine_sim[car_index], axis=0)
    sorted_similar_cars = sorted(enumerate(similar_cars), key=lambda x: x[1], reverse=True)
    recommended_cars = [cars_df.iloc[car[0]] for car in sorted_similar_cars[:top_n]]
    return recommended_cars

def get_car_recommendations_gui():
    user_budget = float(entry_budget.get())
    recommended_cars = get_car_recommendations(user_budget)
    output_text = "Recommended Cars within Budget:\n\n"
    for car in recommended_cars:
        car_name = car['car_name']
        starting_price = car['starting_price']
        output_text += f"Car: {car_name}, Starting Price: {starting_price}\n"
    messagebox.showinfo("Recommended Cars", output_text)

window = tk.Tk()
window.title("Car Recommendations")
window.geometry("400x200")

label_budget = tk.Label(window, text="Enter your budget:")
label_budget.pack()
entry_budget = tk.Entry(window)
entry_budget.pack()

button_recommend = tk.Button(window, text="Get Recommendations", command=get_car_recommendations_gui)
button_recommend.pack()

window.mainloop()
